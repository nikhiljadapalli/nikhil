let signInFormEl = document.getElementById("signInForm");
let signInEmailEl = document.getElementById("signInEmail");
let signInEmailErrMsgEl = document.getElementById("signInEmailErrMsg");
let signInPasswordEl = document.getElementById("signInPassword");
let signInPasswordErrMsgEl = document.getElementById("signInPasswordErrMsg");
let signInBtnEl = document.getElementById("signInBtn");
let signUpFormEl = document.getElementById("signUpForm");
let signUpEmailEl = document.getElementById("signUpEmail");
let signUpPasswordEl = document.getElementById("signUpPassword");
let signUpSecretEl = document.getElementById("signUpSecret");
let signUpSecretErrMsgEl = document.getElementById("signUpSecretErrMsg");
let signUpPasswordErrMsgEl = document.getElementById("signUpPasswordErrMsg");
let signUpEmailErrMsgEl = document.getElementById("signUpEmailErrMsg");
let signUpBtnEl = document.getElementById("signUpBtn");
let signPageEl = document.getElementById("signPage");
let contactsPageEl = document.getElementById("contactsPage");
let saveBtnEl = document.getElementById("saveBtn");
let contactNameEl = document.getElementById("contactName");
let contactPhnoEl = document.getElementById("contactPhno");
let contactEmailEl = document.getElementById("contactEmail");
let nameCard = document.getElementById("nameCard");
let phnoCard = document.getElementById("phnoCard");
let emailCard = document.getElementById("emailCard");

let enteredEmail;
let enteredPassward;
let contactsStored = [];



function displayContacts(item) {

    let container = document.createElement("div");
    container.classList.add("p-5");
    container.style.borderStyle = "solid";
    nameCard.appendChild(container);

    let para = document.createElement("p");
    para.textContent = item.name;
    para.classList.add("text-dark");
    container.appendChild(para);

    let container1 = document.createElement("div");
    container1.classList.add("p-5");
    container1.style.borderStyle = "solid";
    phnoCard.appendChild(container1);

    let para1 = document.createElement("p");
    para1.textContent = item.phno;
    para1.classList.add("text-dark");
    container1.appendChild(para1);

    let container2 = document.createElement("div");
    container2.classList.add("p-5");
    container2.style.borderStyle = "solid";
    emailCard.appendChild(container2);

    let para2 = document.createElement("p");
    para2.textContent = item.email;
    para2.classList.add("text-dark");
    container2.appendChild(para2);

}

saveBtnEl.onclick = function() {
    let contactNameElVal = contactNameEl.value;
    let contactPhnoElVal = contactPhnoEl.value;
    let contactEmailElVal = contactEmailEl.value;
    if (contactNameElVal === "" || contactPhnoElVal === "" || contactEmailElVal === "") {
        alert("enter all values");
        return;
    } else {
        contactObj = {
            name: contactNameElVal,
            phno: contactPhnoElVal,
            email: contactEmailElVal
        };
        let localSaveKey = JSON.parse(localStorage.getItem(enteredEmail + enteredPassward));
        let localSaveKey1 = localSaveKey.code;
        let localSaveKey2 = localSaveKey.email;
        contactsStored.push(contactObj);
        let stringifiedObj = JSON.stringify(contactsStored);
        localStorage.setItem(localSaveKey1 + localSaveKey2, stringifiedObj);
        displayContacts(contactObj);
        contactNameEl.value = "";
        contactPhnoEl.value = "";
        contactEmailEl.value = "";
    }
};




function createAndAppendContacts(key, value) {
    contactsStored = JSON.parse(localStorage.getItem(value + key));
    for (let item of contactsStored) {
        displayContacts(item);
    }
}

function createLocalStorage(key, value, secret) {
    localStorage.setItem(key, key);
    let emailPasswordObj = {
        email: key,
        password: value,
        code: secret
    };
    let emailPasswordObjString = JSON.stringify(emailPasswordObj);
    localStorage.setItem(key + value, emailPasswordObjString);
    let localStorageEmailCheck = localStorage.getItem(key);
    if (localStorageEmailCheck === key) {
        let localStorageValue = JSON.parse(localStorage.getItem(key + value));
        if (localStorageValue === null) {
            signInPasswordErrMsgEl.textContent = "Wrong passward*";
        } else if (key === localStorageValue.email && value === localStorageValue.password) {
            enteredEmail = localStorageValue.email;
            enteredPassward = localStorageValue.password;
            let parsedContacts = JSON.stringify(contactsStored);
            localStorage.setItem(secret + key, parsedContacts);
            signInPasswordErrMsgEl.textContent = "";
            signPageEl.classList.add("d-none");
            contactsPageEl.classList.remove("d-none");
            createAndAppendContacts(key, secret);
        }
    }
}

function checkLocalStorage(key, value) {
    let localStorageEmailCheck = localStorage.getItem(key);
    if (localStorageEmailCheck === null) {
        alert("Please Create an Account!");
        return;
    } else if (localStorageEmailCheck === key) {
        let localStorageValue = JSON.parse(localStorage.getItem(key + value));
        console.log(localStorageValue);
        if (localStorageValue === null) {
            signInPasswordErrMsgEl.textContent = "Wrong passward*";
        } else if (key === localStorageValue.email && value === localStorageValue.password) {
            enteredEmail = localStorageValue.email;
            console.log("11111")
            enteredPassward = localStorageValue.password;
            signInPasswordErrMsgEl.textContent = "";
            signPageEl.classList.add("d-none");
            contactsPageEl.classList.remove("d-none");
            createAndAppendContacts(key, localStorageValue.code);
        }
    }
}

let signInEmailElFunction = function() {
    let signInEmailValue = signInEmailEl.value;
    if (signInEmailValue === "") {
        signInEmailErrMsgEl.textContent = "Enter email*";
    } else {
        signInEmailErrMsgEl.textContent = "";
    }
};
let signInPasswordElFunction = function() {
    let signInPasswordValue = signInPasswordEl.value;
    if (signInPasswordValue === "") {
        signInPasswordErrMsgEl.textContent = "Enter passward*";
    } else {
        signInPasswordErrMsgEl.textContent = "";
    }
};
let signUpEmailElFunction = function() {
    let signUpEmailValue = signUpEmailEl.value;
    if (signUpEmailValue === "") {
        signUpEmailErrMsgEl.textContent = "Enter email*";
    } else {
        signUpEmailErrMsgEl.textContent = "";
    }
};
let signUpPasswordElFunction = function() {
    let signUpPasswordValue = signUpPasswordEl.value;
    if (signUpPasswordValue === "") {
        signUpPasswordErrMsgEl.textContent = "Enter passward*";
    } else {
        signUpPasswordErrMsgEl.textContent = "";
    }
};
let signUpSecretElFunction = function() {
    let signUpSecretElValue = signUpSecretEl.value;
    if (signUpSecretElValue === "") {
        signUpSecretErrMsgEl.textContent = "Enter secretcode*";
    } else {
        signUpSecretErrMsgEl.textContent = "";
    }
};

function signUpFunction() {
    let signUpEmailElValue = signUpEmailEl.value;
    let signUpPasswordElValue = signUpPasswordEl.value;
    let signUpSecretElValue = signUpSecretEl.value;
    signUpEmailElFunction();
    signUpPasswordElFunction();
    signUpSecretElFunction();
    if (signUpEmailElValue !== "" && signUpPasswordElValue !== "" && signUpSecretElValue !== "") {
        if (signUpPasswordElValue === signUpSecretElValue) {
            signUpSecretErrMsgEl.textContent = "";
            createLocalStorage(signUpEmailElValue, signUpPasswordElValue, signUpSecretElValue);
        } else {
            signUpSecretErrMsgEl.textContent = "passward don't match*";
        }
    }
}

function signInFunction() {
    let signInEmailElValue = signInEmailEl.value;
    let signInPasswordElValue = signInPasswordEl.value;
    signInEmailElFunction();
    signInPasswordElFunction();
    if (signInEmailElValue !== "" && signInPasswordElValue !== "") {
        checkLocalStorage(signInEmailElValue, signInPasswordElValue);
    }
}

signInEmailEl.addEventListener("change", signInEmailElFunction);
signInPasswordEl.addEventListener("change", signInPasswordElFunction);
signUpEmailEl.addEventListener("change", signUpEmailElFunction);
signUpPasswordEl.addEventListener("change", signUpPasswordElFunction);
signUpSecretEl.addEventListener("change", signUpSecretElFunction);


signInFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    signInFunction();
});
signUpFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    signUpFunction();
});